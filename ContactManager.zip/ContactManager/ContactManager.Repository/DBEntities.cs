﻿using ContactManager.Models;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;
using System.Reflection;

namespace ContactManager.Repository
{
    public class DBEntities
    {
        private string path = "";
        private string jsonData = "";

        public DBEntities() {
            path = @"D:\rohan sawant\Prj\ContactManager\ContactManager.Repository\Data\Data.json";
            //var p = System.AppDomain.CurrentDomain.BaseDirectory;
            //var p1 = System.Reflection.Assembly.GetExecutingAssembly().CodeBase;
            //var directory = System.IO.Path.GetDirectoryName(p1);
            //StreamReader r = new StreamReader(@"D:\rohan sawant\Prj\ContactManager\ContactManager.Repository\Data\Data.json"))
            //{
            //    jsonData = r.ReadToEnd();                
            //}
        }

        public IList<ContactModel> GetContactEntity() {
            using (StreamReader r = new StreamReader(path))
            {
                jsonData = r.ReadToEnd();
            }
            
            List<ContactModel> items = JsonConvert.DeserializeObject<List<ContactModel>>(jsonData);
            return items;
        }

        public bool UpdateContactEntity(IList<ContactModel> contacts)
        {
            string json = JsonConvert.SerializeObject(contacts.ToArray());
            System.IO.File.WriteAllText(path, json);
            return true;
        }
    }
}
