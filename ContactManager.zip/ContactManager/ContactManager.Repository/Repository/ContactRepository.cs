﻿using ContactManager.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ContactManager.Repository
{
    public class ContactRepository
    {
        #region Declaration
        DBEntities _dBEntities;
        private IList<ContactModel> contacts;
        #endregion

        #region Constructor
        public ContactRepository()
        {
            _dBEntities = new DBEntities();
            contacts = _dBEntities.GetContactEntity();
        }
        #endregion


        #region Methods

        public IEnumerable<ContactModel> Get()
        {
            return contacts;
        }

        public ContactModel Get(string id)
        {
            return contacts.FirstOrDefault(p => p.contactId.ToString() == id);
        }

        public ContactModel Add(ContactModel contact)
        {
            int id = contacts.Max(x => x.contactId);
            contact.contactId = id + 1;
            contacts.Add(contact);
            if (!_dBEntities.UpdateContactEntity(contacts))
            {
                contacts.Remove(contact);
                contact.contactId = 0;
            }

            return contact;
            
        }

        public bool Remove(string id)
        {
            var contact = contacts.FirstOrDefault(p => p.contactId.ToString() == id);
            
            if (contact == null) {
                return false;
            }

            contacts.Remove(contact);

            if (!_dBEntities.UpdateContactEntity(contacts))
            {
                contacts.Add(contact);
                return false;
            }
            
            return true;
        }

        public bool Update(ContactModel contact)
        {
            foreach (var item in contacts.Where(p => p.contactId == contact.contactId))
            {
                item.firstName = contact.firstName;
                item.lastName = contact.lastName;
                item.email = contact.email;
                item.phoneNumber = contact.phoneNumber;
                item.status = item.status;

                if (!_dBEntities.UpdateContactEntity(contacts))
                {
                    contacts.Add(contact);
                    return false;
                }
                return true;
            }

            return false;
        }
        
        #endregion
    }
}
