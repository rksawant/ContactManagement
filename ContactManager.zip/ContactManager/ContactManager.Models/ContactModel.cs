﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace ContactManager.Models
{
    [DataContract]
    public class ContactModel
    {
        [DataMember(Name = "contactId", Order = 1)]
        public int contactId { get; set; }

        [Required]
        [StringLength(15, MinimumLength = 1, ErrorMessage = "firstName must be greater than 0 characters in length")]
        [RegularExpression(@"^[a-zA-Z]+$", ErrorMessage = "firstName can only contain alphabets")]
        [DataMember(Name = "firstName", Order = 2)]
        public string firstName { get; set; }

        //[Required]
        //[StringLength(15, MinimumLength = 1, ErrorMessage = "lastName must be greater than 0 characters in length")]
        [StringLength(15)]
        [RegularExpression(@"^[a-zA-Z]+$", ErrorMessage = "lastName can only contain alphabets")]
        [DataMember(Name = "lastName", Order = 3)]
        public string lastName { get; set; }

        [Required]
        [StringLength(25, ErrorMessage = "email must not be greater than 25 characters in length")]
        [RegularExpression(@"([\w\.\-]+)@([\w\-]+)((\.(\w){2,3})+)", ErrorMessage = "email must be valid")]
        [DataMember(Name = "email", Order = 4)]
        public string email { get; set; }


        [Required]
        [StringLength(10)]
        [RegularExpression(@"[\d]{10}", ErrorMessage = "phoneNumber must be valid")]
        [DataMember(Name = "phoneNumber", Order = 5)]

        public string phoneNumber { get; set; }

        [DataMember(Name = "status", Order = 6)]
        public bool status { get; set; }

        public ContactModel() { }
    }
}
