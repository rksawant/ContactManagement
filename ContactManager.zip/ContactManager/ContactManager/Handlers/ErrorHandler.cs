﻿using ContactManager.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Formatting;
using System.Threading;
using System.Threading.Tasks;
using System.Web;
using System.Web.Http;
using System.Web.Http.ExceptionHandling;

namespace ContactManager.Handlers
{
    public class ErrorHandler : ExceptionHandler
    {
        public override void Handle(ExceptionHandlerContext context)
        {
            BaseResponse Response = new BaseResponse();
            Response.IsSuccess = false;
            HttpStatusCode Code = HttpStatusCode.InternalServerError;
            Exception Exception = context.Exception;
            if (Exception is UnauthorizedAccessException)
            {
                Response.Message = "Failed to CustomAuthorize";
                Code = HttpStatusCode.Unauthorized;
            }
            else if (Exception is System.Data.Entity.Core.EntityException)
            {
                if (((System.Data.SqlClient.SqlException)(Exception.GetBaseException())).Class == 11)
                {
                    Response.Message = Exception.InnerException.Message.ToString();
                    Code = HttpStatusCode.OK;
                }
                else
                {
                    Response.Message = "An unknown error occured and has been logged for further investigation";
                    Elmah.ErrorSignal.FromCurrentContext().Raise(Exception);
                }
            }
            else
            {
                Response.Message = "An unknown error occured and has been logged for further investigation";
                Elmah.ErrorSignal.FromCurrentContext().Raise(Exception);
            }
            var Result = new HttpResponseMessage(Code)
            {
                Content = new ObjectContent(typeof(BaseResponse), Response, new JsonMediaTypeFormatter()),
                ReasonPhrase = Response.Message
            };
            context.Result = new ErrorResult(context.Request, Result);
        }
        public override bool ShouldHandle(ExceptionHandlerContext context)
        {
            return true;
        }
    }

    public class ErrorResult : IHttpActionResult
    {
        private HttpRequestMessage _request;
        private HttpResponseMessage _httpResponseMessage;

        public ErrorResult(HttpRequestMessage request, HttpResponseMessage httpResponseMessage)
        {
            _request = request;
            _httpResponseMessage = httpResponseMessage;
        }
        public Task<HttpResponseMessage> ExecuteAsync(CancellationToken cancellationToken)
        {
            return Task.FromResult(_httpResponseMessage);
        }
    }
}