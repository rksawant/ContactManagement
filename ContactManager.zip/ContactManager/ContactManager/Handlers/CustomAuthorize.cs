﻿using ContactManager.Models;
using System.Net;
using System.Net.Http;
using System.Net.Http.Formatting;
using System.Web;
using System.Web.Http;
using System.Web.Http.Controllers;

namespace ContactManager.Handlers
{
    public class CustomAuthorize : AuthorizeAttribute
    {
        protected override void HandleUnauthorizedRequest(HttpActionContext actionContext)
        {
            BaseResponse objBaseResponse = new BaseResponse();
            objBaseResponse.IsSuccess = false;
            objBaseResponse.Message = "Failed to CustomAuthorize";
            HttpStatusCode Code = HttpStatusCode.Unauthorized;

            Elmah.ErrorSignal.FromCurrentContext().Raise(new HttpException(401, "401 - Failed to CustomAuthorize"));

            actionContext.Response = new HttpResponseMessage(Code)
            {
                Content = new ObjectContent(typeof(BaseResponse), objBaseResponse, new JsonMediaTypeFormatter()),
                ReasonPhrase = objBaseResponse.Message
            };

        }
    }
}