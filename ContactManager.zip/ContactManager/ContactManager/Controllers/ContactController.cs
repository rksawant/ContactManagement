﻿using ContactManager.Business.IServices;
using ContactManager.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Description;

namespace ContactManager.Controllers
{
    public class ContactController : BaseController
    {
        #region Declaration
        private IContactService _IContactService = null;
        #endregion

        #region Constructor
        public ContactController(IContactService iContactService)
        {
            _IContactService = iContactService;
        }
        #endregion

        [HttpGet, ResponseType(typeof(BaseResponse))]
        public HttpResponseMessage Get()
        {
            var contacts = _IContactService.Get();
            
            if (contacts.Count() > 0)
                return Success(contacts, "Success");
            else
                return Error("No Results", HttpStatusCode.NotFound);                        
        }

        [HttpGet, ResponseType(typeof(BaseResponse))]
        public HttpResponseMessage Get(string id)
        {
            ContactModel contactModel = _IContactService.Get(id);
            if (contactModel != null && contactModel.contactId != 0)
            {
                return Success(contactModel, "Success");
            }
            else
                return Error("No Result", HttpStatusCode.NotFound);

        }

        [HttpPost]
        public HttpResponseMessage Add(ContactModel contactModel)
        {
            if (contactModel == null || !ModelState.IsValid)
            {                
                string messages = string.Join("; ", ModelState.Values.SelectMany(x => x.Errors).Select(x => x.ErrorMessage));
                return Error("Please Send Proper Data : " + messages);
            }

            //////////?????????????????
            if (contactModel.contactId < 0 ||contactModel.contactId > 0)
                return Error("Please Use HTTPPut To Update Resource", HttpStatusCode.MethodNotAllowed);

            contactModel = _IContactService.Add(contactModel);
            if (contactModel.contactId > 0)
                return Success(contactModel, "Contact Added Successfully");
            else if (contactModel.contactId == 0)
                return Error("Something Wrong");
            else
                return Error("Contact Already Exists");
        }

        [HttpPut]
        public HttpResponseMessage Update(ContactModel contactModel)
        {
            if (contactModel == null || !ModelState.IsValid)
            {
                string messages = string.Join("; ", ModelState.Values.SelectMany(x => x.Errors).Select(x => x.ErrorMessage));
                return Error("Please Send Proper Data : " + messages);
            }

            if (_IContactService.Update(contactModel))
                return Success(contactModel, "Contact Updated Successfully");
            else
                return Error("No Contact Found", HttpStatusCode.NotFound);
        }

        [HttpDelete]
        public HttpResponseMessage Remove(string id)
        {
            if (_IContactService.Remove(id))                
                return Success<object>(null, "Contact Deleted Successfully");
            else
                return Error("No Contact Found", HttpStatusCode.NotFound);
        }
    }
}
