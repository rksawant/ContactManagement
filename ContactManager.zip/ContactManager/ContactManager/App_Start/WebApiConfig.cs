﻿using ContactManager.Business.IServices;
using ContactManager.Business.Services;
using ContactManager.Handlers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http.Formatting;
using System.Web.Http;
using System.Web.Http.ExceptionHandling;
using Unity;
using Unity.Lifetime;

namespace ContactManager
{
    public static class WebApiConfig
    {
        public static void Register(HttpConfiguration config)
        {
            RegisterMappings(config);
            
            // Web API routes
            config.MapHttpAttributeRoutes();

            config.Routes.MapHttpRoute(
                name: "DefaultApi",
                routeTemplate: "api/{controller}/{id}",
                defaults: new { id = RouteParameter.Optional }
            );

            HandleCustomConfiguration(config);
        }

        private static void RegisterMappings(HttpConfiguration config)
        {
            var container = new UnityContainer();
            container.RegisterType<IContactService, ContactService>(new HierarchicalLifetimeManager());
            config.DependencyResolver = new UnityResolver(container);
        }

        private static void HandleCustomConfiguration(HttpConfiguration config)
        {
            //ELMAH
            GlobalConfiguration.Configuration.Services.Replace(typeof(IExceptionHandler), new ErrorHandler());

            //Remove XML Formatter
            config.Formatters.Remove(config.Formatters.XmlFormatter);
        }
    }
}
