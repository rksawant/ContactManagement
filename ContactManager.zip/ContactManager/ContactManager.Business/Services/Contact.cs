﻿using ContactManager.Business.IServices;
using ContactManager.Models;
using ContactManager.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ContactManager.Business.Services
{
    public class ContactService : IContactService
    {

        #region Declaration
        private ContactRepository _ContactRepository;
        #endregion

        #region Constructor
        /// <summary>
        /// Constructor for ContactRepository
        /// </summary>
        public ContactService()
        {
            _ContactRepository = new ContactRepository();
        }
        #endregion

        #region Methods

        public IEnumerable<ContactModel> Get()
        {
            return _ContactRepository.Get();
        }

        public ContactModel Get(string id)
        {
            return _ContactRepository.Get(id);
        }

        public ContactModel Add(ContactModel contact)
        {
            return _ContactRepository.Add(contact);
        }

        public bool Remove(string id)
        {
           return _ContactRepository.Remove(id);
        }

        public bool Update(ContactModel contact)
        {
            return _ContactRepository.Update(contact);
        }

        #endregion
    }
}
