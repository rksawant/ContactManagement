﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ContactManager.Models;

namespace ContactManager.Business.IServices
{
    public interface IContactService
    {

        IEnumerable<ContactModel> Get();

        ContactModel Get(string Id);

        ContactModel Add(ContactModel contact);

        bool Remove(string Id);

        bool Update(ContactModel contact);
    }
}
