﻿using System.ComponentModel.DataAnnotations;
using System.Runtime.Serialization;

namespace ContactManager.Models
{
    [DataContract]
    public class ContactModel
    {
        [DataMember(Name = "id", Order = 1)]
        public int? contactId { get; set; }

        [Required]
        [StringLength(15, MinimumLength = 1, ErrorMessage = "fName must be greater than 0 characters in length")]
        [RegularExpression(@"^[a-zA-Z]+$", ErrorMessage = "fName can only contain alphabets")]
        [DataMember(Name = "fName", Order = 2)]
        public string firstName { get; set; }

        //[Required]
        [StringLength(15)]
        [RegularExpression(@"^[a-zA-Z]+$", ErrorMessage = "lName can only contain alphabets")]
        [DataMember(Name = "lName", Order = 3)]
        public string lastName { get; set; }

        [Required]
        [StringLength(25, ErrorMessage = "email must not be greater than 25 characters in length")]
        [RegularExpression(@"([\w\.\-]+)@([\w\-]+)((\.(\w){2,3})+)", ErrorMessage = "email must be valid")]
        [DataMember(Name = "email", Order = 4)]
        public string email { get; set; }
                
        [Required]
        [StringLength(10)]
        [RegularExpression(@"\(?\d{3}\)?-? *\d{3}-? *-?\d{4}", ErrorMessage = "phone must be valid")]
        [DataMember(Name = "phone", Order = 5)]
        public string phoneNumber { get; set; }

        [DataMember(Name = "status", Order = 6)]
        public bool status { get; set; }

        public ContactModel() { }
    }
}
