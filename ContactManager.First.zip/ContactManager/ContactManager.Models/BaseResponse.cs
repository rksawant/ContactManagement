﻿using System.Runtime.Serialization;

namespace ContactManager.Models
{
    [DataContract]
    public class BaseResponse
    {
        [DataMember(Name = "IsSuccess", IsRequired = true)]
        public bool IsSuccess { get; set; }

        [DataMember(Name = "Message", IsRequired = false)]
        public string Message { get; set; }

        [DataMember(Name = "Data", IsRequired = false)]        
        public object Data { get; set; }

        public BaseResponse() { }
    }
}
