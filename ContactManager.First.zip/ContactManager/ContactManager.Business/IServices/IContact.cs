﻿using System.Collections.Generic;
using ContactManager.Models;

namespace ContactManager.Business.IServices
{
    public interface IContactService
    {

        IEnumerable<ContactModel> Get();

        ContactModel Get(int Id);

        ContactModel Add(ContactModel contact);

        bool Remove(int Id);

        ContactModel Update(ContactModel contact);
    }
}
