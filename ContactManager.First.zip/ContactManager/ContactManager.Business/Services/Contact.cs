﻿using ContactManager.Business.IServices;
using ContactManager.Models;
using ContactManager.Repository;
using System.Collections.Generic;

namespace ContactManager.Business.Services
{
    public class ContactService : IContactService
    {

        #region Declaration
        private ContactRepository _ContactRepository;
        #endregion

        #region Constructor
        /// <summary>
        /// Constructor for ContactRepository
        /// </summary>
        public ContactService()
        {
            _ContactRepository = new ContactRepository();
        }
        #endregion

        #region Methods

        public IEnumerable<ContactModel> Get()
        {
            return _ContactRepository.Get();
        }

        public ContactModel Get(int id)
        {
            return _ContactRepository.Get(id);
        }

        public ContactModel Add(ContactModel contact)
        {
            return _ContactRepository.Add(contact);
        }

        public bool Remove(int id)
        {
           return _ContactRepository.Remove(id);
        }

        public ContactModel Update(ContactModel contact)
        {
            return _ContactRepository.Update(contact);
        }

        #endregion
    }
}
