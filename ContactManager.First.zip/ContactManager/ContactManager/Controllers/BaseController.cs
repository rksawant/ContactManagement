﻿using ContactManager.Models;
using System;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace ContactManager.Controllers
{
    public class BaseController : ApiController
    {
        
        protected HttpResponseMessage Success<T>(T Data) {
            BaseResponse objBaseResponse = new BaseResponse();
            objBaseResponse.IsSuccess = true;
            objBaseResponse.Message = "";
            objBaseResponse.Data = Data;

            return this.Request.CreateResponse(HttpStatusCode.OK, objBaseResponse);
        }

        protected HttpResponseMessage Success<T>(T Data, string Message)
        {
            BaseResponse objBaseResponse = new BaseResponse();
            objBaseResponse.IsSuccess = true;
            objBaseResponse.Message = Message;
            objBaseResponse.Data = Data;

            return this.Request.CreateResponse(HttpStatusCode.OK, objBaseResponse);
        }

        protected HttpResponseMessage Error(string Message)
        {
            BaseResponse objBaseResponse = new BaseResponse();
            objBaseResponse.IsSuccess = false;
            objBaseResponse.Message = Message;
            objBaseResponse.Data = null;

            return this.Request.CreateResponse(HttpStatusCode.OK, objBaseResponse);
        }

        protected HttpResponseMessage Error(string Message, HttpStatusCode Code)
        {
            BaseResponse objBaseResponse = new BaseResponse();
            objBaseResponse.IsSuccess = false;
            objBaseResponse.Message = Message;
            objBaseResponse.Data = null;
            return this.Request.CreateResponse(Code, objBaseResponse);
        }

        protected HttpResponseMessage Error(Exception Exception)
        {
            BaseResponse objBaseResponse = new BaseResponse();
            objBaseResponse.IsSuccess = false;
            objBaseResponse.Message = "Something Wrong! Try Again.";
            objBaseResponse.Data = null;
            HttpStatusCode ResponseCode = HttpStatusCode.InternalServerError;
            return this.Request.CreateResponse(ResponseCode, objBaseResponse);
        }

    }
}
