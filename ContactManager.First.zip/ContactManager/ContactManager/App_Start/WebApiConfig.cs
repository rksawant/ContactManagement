﻿using ContactManager.Handlers;
using System.Linq;
using System.Web.Http;
using System.Web.Http.ExceptionHandling;
using Unity;
using System.Net.Http.Formatting;
using Newtonsoft.Json.Serialization;
using ContactManager.Business.IServices;
using ContactManager.Business.Services;
using Unity.Lifetime;

namespace ContactManager
{
    public static class WebApiConfig
    {
        public static void Register(HttpConfiguration config)
        {
            RegisterMappings(config);

            // Web API routes
            config.MapHttpAttributeRoutes();

            config.Routes.MapHttpRoute(
                name: "DefaultApi",
                routeTemplate: "api/{controller}/{id}",
                defaults: new { id = RouteParameter.Optional }
            );

            HandleCustomConfiguration(config);
        }

        private static void RegisterMappings(HttpConfiguration config)
        {
            var container = new UnityContainer();
            container.RegisterType<IContactService, ContactService>(new HierarchicalLifetimeManager());
            config.DependencyResolver = new UnityResolver(container);

            //List<Assembly> AssembliesToRegister = AppDomain.CurrentDomain.GetAssemblies().Where(ass => ass.FullName.StartsWith("GST.Business")).ToList();
            //// Web API configuration and services
            //var container = new UnityContainer();
            //container.RegisterType<IContactService, ContactService>(new HierarchicalLifetimeManager());
            //container.RegisterTypes(AllClasses.FromAssemblies(true, AssembliesToRegister.ToArray())
            //  , WithMappings.FromMatchingInterface
            //  , WithName.Default
            //  , WithLifetime.Transient);

            config.DependencyResolver = new UnityResolver(container);
        }

        private static void HandleCustomConfiguration(HttpConfiguration config)
        {
            //ELMAH
            GlobalConfiguration.Configuration.Services.Replace(typeof(IExceptionHandler), new ErrorHandler());

            //Remove XML Formatter
            var jsonFormatter = config.Formatters.OfType<JsonMediaTypeFormatter>().First();
            jsonFormatter.SerializerSettings.ContractResolver = new CamelCasePropertyNamesContractResolver();

            //GlobalConfiguration.Configuration.Formatters.JsonFormatter.MediaTypeMappings.Add(new RequestHeaderMapping("Accept", "text/html", StringComparison.InvariantCultureIgnoreCase, true, "application/json"));
            config.Formatters.Remove(config.Formatters.XmlFormatter);
        }
    }
}
