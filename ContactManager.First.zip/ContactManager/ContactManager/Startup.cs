﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartup(typeof(ContactManager.App_Start.Startup))]

namespace ContactManager.App_Start
{
    public partial class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            ConfigureAuth(app);
        }
    }
}