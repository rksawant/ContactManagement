﻿using ContactManager.Business.IServices;
using ContactManager.Business.Services;
using ContactManager.Controllers;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Net.Http;
using ContactManager.Models;
using System.Web.Http;

namespace ContactManager.Tests
{
    [TestClass]
    public class ContactControllerTest
    {
        //#region Declaration
        private IContactService _IContactService = new ContactService();
        //#endregion

        [TestMethod]
        public void Get()
        {
            // Arrange
            ContactController controller = new ContactController(_IContactService);
            controller.Request = new HttpRequestMessage();
            controller.Request.SetConfiguration(new HttpConfiguration());

            // Act
            HttpResponseMessage result = controller.Get();

            // Assert
            Assert.IsNotNull(result);
        }

        [TestMethod]
        public void GetById()
        {
            // Arrange
            ContactController controller = new ContactController(_IContactService);
            controller.Request = new HttpRequestMessage();
            controller.Request.SetConfiguration(new HttpConfiguration());

            // Act
            HttpResponseMessage result = controller.Get(1);

            // Assert
            Assert.IsNotNull(result);
        }

        [TestMethod]
        public void Post()
        {
            // Arrange
            ContactController controller = new ContactController(_IContactService);
            controller.Request = new HttpRequestMessage();
            controller.Request.SetConfiguration(new HttpConfiguration());

            ContactModel model = new ContactModel();
            model.firstName = "Test1"; model.lastName = "Test2";
            model.email = "test@test.com"; model.phoneNumber = "9090909090"; model.status = true;

            // Act
            HttpResponseMessage result = controller.Add(model);

            // Assert
            Assert.IsNotNull(result);
        }

        [TestMethod]
        public void Put()
        {
            // Arrange
            ContactController controller = new ContactController(_IContactService);
            controller.Request = new HttpRequestMessage();
            controller.Request.SetConfiguration(new HttpConfiguration());

            ContactModel model = new ContactModel();
            model.contactId = 100;  model.firstName = "Test11"; model.lastName = "Test22";
            model.email = "test1@test1.com"; model.phoneNumber = "9190909091"; model.status = true;

            // Act
            HttpResponseMessage result = controller.Update(model);

            // Assert
            Assert.IsNotNull(result);
        }

        [TestMethod]
        public void Remove()
        {
            // Arrange
            ContactController controller = new ContactController(_IContactService);
            controller.Request = new HttpRequestMessage();
            controller.Request.SetConfiguration(new HttpConfiguration());

            // Act
            HttpResponseMessage result = controller.Remove(1);

            // Assert
            Assert.IsNotNull(result);
        }
    }
}
