﻿using ContactManager.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ContactManager.Repository
{
    public class ContactRepository
    {
        #region Declaration
        ContactManagerEntities _dBContext = new ContactManagerEntities();
        #endregion

        //#region Constructor
        //public ContactRepository()
        //{
        //    _dBContext = new ContactManagerEntities();
        //}
        //#endregion

        
        #region Methods

        public IEnumerable<ContactModel> Get()
        {
            var result = _dBContext.Contacts.Select(x => new ContactModel { contactId = x.ContactId, firstName = x.FirstName, lastName = x.LastName, email = x.Email, phoneNumber = x.PhoneNumber, status = x.Status }).ToList();
            return result;
        }

        public ContactModel Get(string id)
        {
            return new ContactModel { contactId = 1, email = "", firstName = "", lastName = "", phoneNumber = "", status =false };
            //var result = _dBContext.Contacts.Where(x => x.ContactId.ToString() == id).Select(x => new ContactModel { contactId = x.ContactId, firstName = x.FirstName, lastName = x.LastName, email = x.Email, phoneNumber = x.PhoneNumber, status = x.Status })
            //    .FirstOrDefault();
            //return result;
        }

        public ContactModel Add(ContactModel contact)
        {
            return new ContactModel();
        }

        public bool Remove(string id)
        {
            return true;
        }

        public bool Update(ContactModel contact)
        {
            return true;
        }
        
        #endregion
    }
}
