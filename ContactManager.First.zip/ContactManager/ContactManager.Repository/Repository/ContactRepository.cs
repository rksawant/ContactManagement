﻿using ContactManager.Models;
using System.Collections.Generic;
using System.Linq;

namespace ContactManager.Repository
{
    public class ContactRepository
    {
        #region Declaration
        DBEntities _dBEntities;
        private IList<ContactModel> contacts;
        #endregion

        #region Constructor
        public ContactRepository()
        {
            _dBEntities = new DBEntities();
            contacts = _dBEntities.GetContactEntity();
        }
        #endregion


        #region Methods

        public IEnumerable<ContactModel> Get()
        {
            return contacts;
        }

        public ContactModel Get(int id)
        {
            if (contacts == null)
                return null;
            else
                return contacts.FirstOrDefault(p => p.contactId == id);
        }

        public ContactModel Add(ContactModel contact)
        {
            int id = 0;
            if (contacts != null)
                id = contacts.Max(x => x.contactId ?? 0);
            else
                contacts = new List<ContactModel>();

            //Check duplicate email id
            if (contacts.Where(c=>c.email == contact.email).ToList().Count() > 0)
            {
                contact.contactId = -1;
            }
            else
            {
                contact.contactId = id + 1;
                contacts.Add(contact);
                if (!_dBEntities.UpdateContactEntity(contacts))
                {
                    contacts.Remove(contact);
                    contact.contactId = 0;
                }
            }
            return contact;            
        }

        public bool Remove(int id)
        {
            var contact = contacts.FirstOrDefault(p => p.contactId == id);
            
            if (contact == null) {
                return false;
            }

            contacts.Remove(contact);

            if (!_dBEntities.UpdateContactEntity(contacts))
            {
                contacts.Add(contact);
                return false;
            }
            
            return true;
        }

        public ContactModel Update(ContactModel contact)
        {         
            if (!(contacts.Where(c => c.email == contact.email && c.contactId != (contact.contactId ?? 0)).ToList().Count() > 0))
            {
                foreach (var item in contacts.Where(p => p.contactId == (contact.contactId ?? 0)))
                {
                    item.firstName = contact.firstName;
                    item.lastName = contact.lastName;
                    item.email = contact.email;
                    item.phoneNumber = contact.phoneNumber;
                    item.status = item.status;

                    if (!_dBEntities.UpdateContactEntity(contacts))
                    {
                        //something wrong
                        contact.contactId = 0;
                    }
                }
            }
            else
                //contact email already exists
                contact.contactId = -1;

            return contact;           
        }
        
        #endregion
    }
}
