﻿using ContactManager.Models;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;
using System.Reflection;

namespace ContactManager.Repository
{
    public class DBEntities
    {
        private string path = "";        

        public DBEntities() {
            path = System.AppDomain.CurrentDomain.BaseDirectory;
            System.IO.DirectoryInfo directoryInfo = System.IO.Directory.GetParent(System.IO.Directory.GetParent(path).FullName);
            path = directoryInfo.FullName + "\\ContactManager.Repository\\Data\\Data.json";
            
        }

        public IList<ContactModel> GetContactEntity() {
            string jsonData = "";
            using (StreamReader r = new StreamReader(path))
            {
                jsonData = r.ReadToEnd();
            }
            
            List<ContactModel> items = JsonConvert.DeserializeObject<List<ContactModel>>(jsonData);
            return items;
        }

        public bool UpdateContactEntity(IList<ContactModel> contacts)
        {
            string json = JsonConvert.SerializeObject(contacts.ToArray());
            System.IO.File.WriteAllText(path, json);
            return true;
        }
    }
}
